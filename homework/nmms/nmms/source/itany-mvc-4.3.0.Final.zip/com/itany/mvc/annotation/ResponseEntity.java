package com.itany.mvc.annotation;

import com.itany.mvc.util.HttpHeaders;


public class ResponseEntity {

    private byte[] data;
    
    private HttpHeaders headers;

	public byte[] getData() {
		return data;
	}

	public HttpHeaders getHeaders() {
		return headers;
	}

	public ResponseEntity(byte[] data, HttpHeaders headers) {
		this.data = data;
		this.headers = headers;
	}
    
    
    
    
}
