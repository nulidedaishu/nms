package com.itany.mvc.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.fileupload.FileItem;

public class CommonsMultipartFile {

	private FileItem fileItem;

	public CommonsMultipartFile(FileItem fileItem) {
		this.fileItem = fileItem;
	}
	
	/**
	 * 
	 * 获取文件的byte数组
	 * <功能详细描述>
	 * @return 文件的byte数组
	 * @see [类、类#方法、类#成员]
	 */
	public byte[] getBytes()
	{
		return fileItem.get();
	}
	
	/**
	 * 
	 * 获取文件类型
	 * <功能详细描述>
	 * @return 文件类型
	 * @see [类、类#方法、类#成员]
	 */
	public String getContentType()
	{
		return fileItem.getContentType();
	}
	
	/**
	 * 获取文件的输出流
	 * <功能详细描述>
	 * @return 文件的输出流
	 * @throws IOException
	 * @see [类、类#方法、类#成员]
	 */
	public InputStream	getInputStream() throws IOException
	{
		return fileItem.getInputStream();
	}
	
	/**
	 * 
	 * 文件请求参数名
	 * <功能详细描述>
	 * @return 请求参数名
	 * @see [类、类#方法、类#成员]
	 */
	public String getName()
	{
		return fileItem.getFieldName();
	}
	
	/**
	 * 
	 * 获取文件名
	 * <功能详细描述>
	 * @return 文件名
	 * @see [类、类#方法、类#成员]
	 */
	public String getOriginalFilename()
	{
		return fileItem.getName();
	}
	
	/**
	 * 
	 * 获取文件大小
	 * <功能详细描述>
	 * @return 文件大小
	 * @see [类、类#方法、类#成员]
	 */
	public long getSize()
	{
		return fileItem.getSize();
	}
	
	/**
	 * 
	 * 是否为空文件
	 * <功能详细描述>
	 * @return true：如果文件不存在或者大小为0
	 * @see [类、类#方法、类#成员]
	 */
	public boolean isEmpty()
	{
		return  fileItem == null || fileItem.getSize() == 0;
	}
	
	/**
	 * 
	 * 另存为
	 * <功能详细描述>
	 * @param dest 要保存的位置对应的java.io.File对象
	 * @throws Exception
	 * @see java.io.File
	 */
	public void transferTo(File dest) throws Exception
	{
		fileItem.write(dest);
	}
	
}
