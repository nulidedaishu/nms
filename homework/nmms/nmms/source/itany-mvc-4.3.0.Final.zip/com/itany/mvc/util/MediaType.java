package com.itany.mvc.util;

public enum MediaType {
	
	 APPLICATION_OCTET_STREAM("application/octet-stream"),
	IMAGE_GIF("image/gif"),
	IMAGE_JPEG("image/jpeg"),
	IMAGE_PNG("image/png");
	
	String type;

	private MediaType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}
	
	
	
	
	
}
