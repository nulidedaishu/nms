package com.itany.mvc.util;

import java.io.UnsupportedEncodingException;

public class HttpHeaders {

	private MediaType mediaType;
	
	private String contentDisposition;

	public void setContentType(MediaType mediaType)
	{
		this.mediaType = mediaType;
	}
	
	public void setContentDispositionFormData(String key,String value) throws UnsupportedEncodingException
	{
		this.contentDisposition = key + ";filename=" +
				new String(value.getBytes("utf-8"),"iso-8859-1");
	}

	public MediaType getMediaType() {
		return mediaType;
	}

	public String getContentDisposition() {
		return contentDisposition;
	}
	
	
	
}
